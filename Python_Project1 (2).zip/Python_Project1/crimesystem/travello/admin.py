from django.contrib import admin
from .models import Crime,Report

# Register your models here.
admin.site.register(Crime),
admin.site.register(Report)
