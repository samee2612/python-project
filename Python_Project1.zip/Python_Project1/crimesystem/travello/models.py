from django.db import models

# Create your models here.
class Crime(models.Model):
    name=models.CharField(max_length=100)
    img=models.ImageField(upload_to='pics')
    dis=models.TextField()
    crimes_reg=models.BigIntegerField()

class Report(models.Model):
    title=models.CharField(max_length=500)
    img = models.ImageField(upload_to='pics')
    dis=models.TextField()
    date=models.DateField()
    place=models.CharField(max_length=60)



