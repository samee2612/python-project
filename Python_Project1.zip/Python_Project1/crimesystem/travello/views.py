from django.shortcuts import render
from .models import *
from django.http import HttpResponse




def index(request):
    crimes=Crime.objects.all()
    reports = Report.objects.all()






    return render(request,"index.html",{'crimes':crimes,'reports':reports})


