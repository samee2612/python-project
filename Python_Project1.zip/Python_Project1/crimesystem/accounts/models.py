from django.shortcuts import render
from django.http import HttpResponse
from django.db import models
# Create your views here.
class Missing_Person(models.Model):
        name=models.CharField(max_length=150)
        img=models.ImageField(upload_to="pics")
        height=models.IntegerField()
        gender=models.CharField(max_length=10,default="")
        age=models.IntegerField()
        wearing=models.CharField(max_length=200)
        missing_date=models.DateField(auto_now=False)
        

class Complaint(models.Model):
        username=models.CharField(max_length=150)
        contact_no=models.BigIntegerField()
        vname=models.CharField(max_length=150)
        fname=models.CharField(max_length=150,default="Not specified")
        police_station=models.CharField(max_length=150)
        com_type=models.CharField(max_length=100)
        desc=models.CharField(max_length=600)
        address=models.CharField(max_length=300,default="Not specified")
        reply=models.CharField(max_length=300,default="None")

class Wanted_Person(models.Model):
        name=models.CharField(max_length=150)
        img=models.ImageField(upload_to="pics")
        height=models.IntegerField()
        gender=models.CharField(max_length=10,default="")
        age=models.IntegerField()
        desc=models.TextField(max_length=500)